<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults = [
	'date'      => [
		'from' => '',
		'to'   => '',
	],
	'date_from' => '',
	'date_to'   => '',
	'period'    => 'daily',
];

$args = wp_parse_args( $_REQUEST, $defaults );

foreach ( $args as $key => $value ) {
	if ( ! is_array( $value ) && $value == 0 ) {
		$args[ $key ] = '';
	}
}

$has_filter = kph_page_has_filter( $args, $defaults );

$date = is_array( $args['date'] ) ? $args['date'] : [];
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';
$date_from = $date_from ?: $args['date_from'];
$date_to   = $date_to ?: $args['date_to'];
$date_from = is_scalar( $date_from ) ? sanitize_text_field( wp_unslash( (string) $date_from ) ) : '';
$date_to   = is_scalar( $date_to ) ? sanitize_text_field( wp_unslash( (string) $date_to ) ) : '';
$period    = is_string( $args['period'] ) ? sanitize_key( $args['period'] ) : 'daily';

if ( ! in_array( $period, [ 'daily', 'monthly', 'yearly' ], TRUE ) ) {
	$period = 'daily';
}

$date_from_g = $date_from ? nooshika_jalali_to_gregorian( $date_from ) : '';
$date_to_g   = $date_to ? nooshika_jalali_to_gregorian( $date_to ) : '';

// Normalize reversed dates before the range builder assigns start/end times.
if ( $date_from_g && $date_to_g && $date_from_g > $date_to_g ) {
	[ $date_from_g, $date_to_g ] = [ $date_to_g, $date_from_g ];
	[ $date_from, $date_to ] = [ $date_to, $date_from ];
}

$DB = new kph_db();

$chart_report = $DB->get_sales_performance_chart_report( [
	'period'    => $period,
	'date_from' => $date_from_g,
	'date_to'   => $date_to_g,
] );

$reports = $DB->get_orders_report(
	$chart_report['ranges']['current_start_sql'],
	$chart_report['ranges']['current_end_sql']
);
$summary = $reports['summary'];
$items   = $reports['items'];

// Pin print links to the effective dates, including default or expanded ranges.
$sales_print_button = static function ( string $section, string $label ) use ( $period, $chart_report ): string {
	$url = add_query_arg( [
		'action'     => 'print',
		'type'       => 'sales-report',
		'section'    => $section,
		'period'     => $period,
		'range_from' => substr( $chart_report['ranges']['current_start_sql'], 0, 10 ),
		'range_to'   => substr( $chart_report['ranges']['current_end_sql'], 0, 10 ),
	], home_url( '/crm' ) );
	return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary ms-1" title="' . esc_attr( $label ) . '" aria-label="' . esc_attr( $label ) . '"><em class="icon ni ni-printer" aria-hidden="true"></em><span>پرینت</span></a>';
};

if ( ! function_exists( 'kph_sales_report_period_label' ) ) {
	function kph_sales_report_period_label( string $period ): string {
		return [
			       'daily'   => 'روزانه',
			       'monthly' => 'ماهیانه',
			       'yearly'  => 'سالیانه',
		       ][ $period ] ?? 'روزانه';
	}
}

if ( ! function_exists( 'kph_sales_report_link' ) ) {
	function kph_sales_report_link( string $period, string $date_from = '', string $date_to = '' ): string {
		$query = [
			'period' => $period,
		];
		
		if ( $date_from !== '' ) {
			$query['date_from'] = $date_from;
		}
		
		if ( $date_to !== '' ) {
			$query['date_to'] = $date_to;
		}
		
		return '/crm/reports-order?' . http_build_query( $query );
	}
}

// A zero baseline has no defined percentage growth. Margin differences use percentage points.
$change_badge = static function ( $current, $previous, bool $percentage_points = FALSE ): string {
	$current  = (float) $current;
	$previous = (float) $previous;
	if ( ! $percentage_points && $previous == 0 && $current != 0 ) {
		return '<span class="badge bg-light text-dark">قابل محاسبه نیست؛ مبنای قبلی صفر است</span>';
	}
	$value = $percentage_points ? $current - $previous : ( $previous != 0 ? ( $current - $previous ) / abs( $previous ) * 100 : 0 );
	$value = round( $value, 2 );
	if ( $value == 0 ) {
		return '<span class="badge bg-light text-dark">بدون تغییر</span>';
	}
	return '<span class="badge ' . ( $value > 0 ? 'bg-success' : 'bg-danger' ) . '">' .
		esc_html( number_format_i18n( abs( $value ), 2 ) . ( $percentage_points ? ' واحد درصد ' : '٪ ' ) . ( $value > 0 ? 'افزایش' : 'کاهش' ) ) . '</span>';
};

$current_summary  = $chart_report['summary']['current'];
$previous_summary = $chart_report['summary']['previous'];

$sales_chart  = $chart_report['charts']['sales'];
$profit_chart = $chart_report['charts']['profit'];
$orders_chart = $chart_report['charts']['orders'];

$dataset_labels = [
	'بازه انتخابی',
	'بازه قبلی',
];

$bucket_label = static function ( string $key ) use ( $period ): string {
	if ( $key === '' ) {
		return '—';
	}
	// The database groups months and years by Gregorian boundaries; do not relabel them as Jalali months.
	if ( $period !== 'daily' ) {
		return str_replace( '-', '/', $key ) . ' میلادی';
	}
	$day = new DateTimeImmutable( $key, wp_timezone() );
	return date_i18n( 'Y/m/d', $day->getTimestamp() );
};
$comparison_labels = [];
$axis_labels = [];
foreach ( $chart_report['ranges']['buckets'] as $bucket ) {
	$axis_labels[] = $period === 'daily'
		? date_i18n( 'm/d', ( new DateTimeImmutable( $bucket['current_key'], wp_timezone() ) )->getTimestamp() )
		: str_replace( '-', '/', $bucket['current_key'] );
	$comparison_labels[] = [
		'انتخابی: ' . $bucket_label( $bucket['current_key'] ),
		'قبلی: ' . $bucket_label( $bucket['previous_key'] ),
	];
}
$has_chart_activity = array_sum( $orders_chart['data'][0] ) + array_sum( $orders_chart['data'][1] ) > 0;
$metrics = [
	'sales'          => [ 'title' => 'فروش کالاهای ارسال‌شده', 'unit' => 'ریال', 'help' => 'مبلغ فروش اقلام غیرهدیهٔ ارسال‌شده، پس از تخفیف.' ],
	'profit'         => [ 'title' => 'برکت ناخالص', 'unit' => 'ریال', 'help' => 'فروش منهای بهای تمام‌شدهٔ کالاهای ارسال‌شده، شامل هدایا.' ],
	'profit_percent' => [ 'title' => 'حاشیهٔ برکت ناخالص', 'unit' => '٪', 'help' => 'برکت ناخالص ÷ فروش × ۱۰۰؛ اختلاف به واحد درصد است.' ],
	'order_count'    => [ 'title' => 'تعداد سفارش‌های معتبر', 'unit' => 'سفارش', 'help' => 'سفارش‌های دارای اقلام با وضعیت تأییدشده، ارسال‌شده یا کسری.' ],
];

?>
<style>
    .kph-sales-report { --kph-current: #6d4aff; --kph-previous: #c47f27; }
    .kph-sales-report .card { border: 1px solid #e8ecf3; border-radius: 14px; box-shadow: 0 3px 14px rgba(31,41,55,.025); }
    .kph-sales-report .amount { font-size: clamp(1.15rem, 1.7vw, 1.5rem); font-weight: 600; font-variant-numeric: tabular-nums; overflow-wrap: anywhere; margin: 12px 0; }
    .kph-sales-report .amount small { font-weight: 400; color: #64748b; }
    .kph-sales-report .badge { white-space: normal; line-height: 1.8; }
    .kph-sales-report .badge.bg-success { background: #e7f6ef !important; color: #16714b; }
    .kph-sales-report .badge.bg-danger { background: #fff0ee !important; color: #b33e36; }
    .kph-sales-report .kph-range-strip { display: flex; flex-wrap: wrap; gap: 12px 32px; align-items: center; }
    .kph-sales-report .kph-range-strip p { margin: 0; }
    .kph-sales-report .kph-current-dot, .kph-sales-report .kph-previous-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: var(--kph-current); margin-inline-end: 6px; }
    .kph-sales-report .kph-previous-dot { background: var(--kph-previous); }
    .kph-sales-report .kph-method { margin-top: 8px; font-size: 12px; color: #64748b; }
    .kph-sales-report .kph-method summary { padding: 4px 0; font-weight: 400; }
    .kph-sales-report .kph-chart-head { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 12px; }
    .kph-sales-report .kph-chart-head h6 { margin: 0 0 5px; }
    .kph-sales-report .kph-chart-legend { display: flex; align-items: center; flex-wrap: wrap; gap: 18px; font-size: 12px; }
    .kph-sales-report .kph-chart-legend label { margin: 0; cursor: pointer; display: flex; align-items: center; gap: 6px; }
    .kph-sales-report .kph-chart-legend input { accent-color: var(--kph-previous); width: 15px; height: 15px; }
    .kph-sales-report .kph-chart-legend input:focus-visible { outline: 2px solid var(--kph-current); outline-offset: 3px; }
    .kph-sales-report .kph-chart-legend i { display: inline-block; width: 19px; border-top: 3px solid var(--kph-current); vertical-align: middle; margin-inline-end: 5px; }
    .kph-sales-report .kph-chart-legend i.previous { border-color: var(--kph-previous); border-top-style: dashed; }
    .kph-sales-report .kph-chart-frame { position: relative; height: 300px; min-width: 0; direction: ltr; }
    .kph-sales-report .kph-chart-frame canvas { width: 100% !important; height: 100% !important; }
    .kph-sales-report .kph-chart-foot { border-top: 1px solid #f0f2f6; padding-top: 10px; margin-top: 6px; font-size: 11px; color: #64748b; }
    .kph-sales-report .kph-metric-help { font-size: 11px; color: #64748b; }
    .kph-sales-report .kph-metric-help summary { padding: 0; font-weight: 400; }
    @media (max-width: 575px) {
        .kph-sales-report .card-inner { padding: 16px; }
        .kph-sales-report .kph-chart-frame { height: 260px; }
        .kph-sales-report .kph-chart-head { align-items: flex-start; }
        .kph-sales-report .kph-chart-legend { width: 100%; }
        .kph-sales-report .amount { font-size: 1.35rem; }
    }
    .kph-sales-report .kph-report-table { width: 100%; border-collapse: collapse; }
    .kph-sales-report .kph-report-table th, .kph-sales-report .kph-report-table td { padding: 12px; border-bottom: 1px solid #e5e9f2; text-align: start; white-space: nowrap; font-variant-numeric: tabular-nums; }
    .kph-sales-report .kph-report-table thead, .kph-sales-report .kph-report-table tfoot { background: #f5f6fa; }
    .kph-sales-report .kph-report-table tbody tr:nth-child(even) { background: #fafbfc; }
    .kph-sales-report summary { cursor: pointer; font-weight: 600; padding: 16px 0; }
    .kph-sales-report .nk-tb-col { font-variant-numeric: tabular-nums; }
</style>
<div class="kph-sales-report">
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش فروش محصولات</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">
                    مقایسه فروش و برکت ناخالص به
                    صورت <?php echo esc_html( kph_sales_report_period_label( $period ) ); ?>
                </p>
            </div>
        </div>

        <div class="card-tools">
            <ul class="btn-toolbar gx-1">
                <li><?php echo $sales_print_button( 'all', 'پرینت کل گزارش فروش' ); ?></li>
                <li>
					<?php
					$filter_fields = [
						[
							'type'  => 'date-range',
							'label' => 'تاریخ گزارش',
							'name'  => 'date',
							'value' => [
								'from' => $date_from ?? '',
								'to'   => $date_to ?? '',
							],
						],
						[
							'type'    => 'select',
							'label'   => 'گروه‌بندی زمانی',
							'name'    => 'period',
							'value'   => $period,
							'col'     => 12,
							'options' => [
								'daily'   => 'روزانه',
								'monthly' => 'ماهیانه',
								'yearly'  => 'سالیانه',
							],
						],
					];
					
					echo kph_get_template( 'components/filter-dropdown.php', [
						'has_filter'    => $has_filter,
						'filter_fields' => $filter_fields,
					] );
					?>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="card">
        <div class="card-inner py-2">
            <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
				<?php foreach (
					[
						'daily'   => 'روزانه',
						'monthly' => 'ماهیانه',
						'yearly'  => 'سالیانه',
					] as $key => $label
				) { ?>
					<?php
					$link = kph_sales_report_link( $key, $date_from, $date_to );
					?>
                    <li class="nav-item">
                        <a href="<?php echo esc_url( $link ); ?>"
                           data-url="<?php echo esc_attr( $link ); ?>"
                           class="nav-link page_activator <?php echo $period === $key ? 'active' : ''; ?>">
                            <span><?php echo esc_html( $label ); ?></span>
                        </a>
                    </li>
				<?php } ?>
            </ul>
        </div>
    </div>
</div>


<div class="nk-block">
    <div class="card">
        <div class="card-inner">
            <div class="kph-range-strip">
                <p><span class="kph-current-dot" aria-hidden="true"></span><strong>بازهٔ انتخابی:</strong> <?php echo esc_html( $chart_report['ranges']['current_label'] ); ?></p>
                <p><span class="kph-previous-dot" aria-hidden="true"></span><strong>بازهٔ قبلی:</strong> <?php echo esc_html( $chart_report['ranges']['previous_label'] ); ?></p>
            </div>
            <details class="kph-method">
            <summary>مبنای محاسبهٔ گزارش</summary>
            <p class="mb-1">تمام نمودارها و جدول‌های این صفحه مربوط به بازهٔ انتخابی بالا هستند. مقایسه با بازهٔ بلافاصله قبل و با تعداد یکسان روز، ماه یا سال انجام می‌شود.</p>
            <p class="mb-1">مبنای تاریخ، زمان ثبت سفارش است؛ مبلغ فروش بر اساس اقلام ارسال‌شدهٔ همان سفارش‌ها محاسبه می‌شود. پیش‌فاکتورها در فروش و برکت لحاظ نمی‌شوند. همهٔ مبالغ به ریال هستند.</p>
            </details>
            <?php if ( $period !== 'daily' ) { ?>
                <p class="mb-1 text-warning">گروه‌بندی <?php echo esc_html( kph_sales_report_period_label( $period ) ); ?> بر اساس تقویم میلادی است و بازه به ابتدا و انتهای ماه یا سال میلادی گسترش می‌یابد.</p>
            <?php } ?>
            <?php if ( ( $date_from === '' ) !== ( $date_to === '' ) ) { ?>
                <p class="mb-0 text-warning">برای اعمال تاریخ دلخواه، ابتدا و انتهای بازه را با هم وارد کنید؛ اکنون بازهٔ پیش‌فرض بالا نمایش داده می‌شود.</p>
            <?php } ?>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="row g-gs">
        <div class="col-12"><div class="kph-chart-head"><h6 class="title">خلاصهٔ عملکرد فروش</h6><?php echo $sales_print_button( 'summary', 'پرینت خلاصهٔ عملکرد فروش' ); ?></div></div>
        <?php foreach ( $metrics as $metric => $meta ) {
            $is_margin = $metric === 'profit_percent';
            $current_defined = ! $is_margin || $current_summary['sales'] > 0;
            $previous_defined = ! $is_margin || $previous_summary['sales'] > 0;
            $precision = $is_margin ? 2 : 0;
            ?>
            <div class="col-sm-6 col-xl-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title"><?php echo esc_html( $meta['title'] ); ?></h6>
                        <div class="amount <?php echo $metric === 'profit' ? ( $current_summary[$metric] < 0 ? 'text-danger' : 'text-success' ) : ''; ?>">
                            <bdi><?php echo $current_defined ? esc_html( number_format_i18n( $current_summary[$metric], $precision ) ) : '—'; ?></bdi>
                            <small class="fs-12px"><?php echo esc_html( $meta['unit'] ); ?></small>
                        </div>
                        <p class="mb-1">بازهٔ قبلی: <bdi><?php echo $previous_defined ? esc_html( number_format_i18n( $previous_summary[$metric], $precision ) ) : '—'; ?></bdi> <?php echo esc_html( $meta['unit'] ); ?></p>
                        <div class="mb-2">
                            <?php echo $current_defined && $previous_defined ? $change_badge( $current_summary[$metric], $previous_summary[$metric], $is_margin ) : '<span class="badge bg-light text-dark">حاشیهٔ برکت بدون فروش مثبت تعریف نمی‌شود</span>'; ?>
                        </div>
                        <details class="kph-metric-help"><summary>نحوهٔ محاسبه</summary><p class="mb-0"><?php echo esc_html( $meta['help'] ); ?></p></details>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php if ( ! $has_chart_activity ) { ?>
    <div class="nk-block"><div class="alert alert-light" role="status">در هیچ‌یک از دو بازه سفارش معتبری دارای اقلام ثبت نشده است؛ نمودار قابل نمایش نیست.</div></div>
<?php } else { ?>
    <?php
    $chart_sections = [
        [ 'title' => 'روند فروش کالاهای ارسال‌شده', 'type' => 'line', 'unit' => 'ریال', 'chart' => $sales_chart, 'help' => 'ارتفاع هر نقطه، مبلغ فروش همان دوره است؛ خط‌ها جمع تجمعی فروش نیستند.' ],
        [ 'title' => 'مقایسهٔ برکت ناخالص', 'type' => 'bar', 'unit' => 'ریال', 'chart' => $profit_chart, 'help' => 'برکت ناخالص = فروش − بهای تمام‌شدهٔ ارسال‌ها. ستون زیر صفر به معنی زیان ناخالص است.' ],
        [ 'title' => 'مقایسهٔ تعداد سفارش‌های معتبر', 'type' => 'bar', 'unit' => 'سفارش', 'chart' => $orders_chart, 'help' => 'تعداد سفارش‌ها بر اساس تاریخ ثبت است؛ سفارش معتبر ممکن است هنوز ارسال نشده باشد.' ],
    ];
    foreach ( $chart_sections as $chart_index => $section ) {
        $has_values = count( array_filter( array_merge( $section['chart']['data'][0], $section['chart']['data'][1] ) ) ) > 0;
        $max_amount = max( array_merge( [ 0 ], array_map( 'abs', $section['chart']['data'][0] ), array_map( 'abs', $section['chart']['data'][1] ) ) );
        $display_divisor = 1;
        $display_unit = $section['unit'];
        if ( $section['unit'] === 'ریال' ) {
            foreach ( [ 1000000000 => 'میلیارد ریال', 1000000 => 'میلیون ریال', 1000 => 'هزار ریال' ] as $divisor => $unit_label ) {
                if ( $max_amount >= $divisor ) {
                    $display_divisor = $divisor;
                    $display_unit = $unit_label;
                    break;
                }
            }
        }
        ?>
        <div class="nk-block">
            <div class="card card-stretch kph-chart-card">
                <div class="card-inner">
                    <div class="kph-chart-head">
                        <div>
                            <h6 class="title"><?php echo esc_html( $section['title'] ); ?> <?php echo $sales_print_button( [ 'sales', 'profit', 'orders' ][$chart_index], 'پرینت ' . $section['title'] ); ?></h6>
                            <span class="sub-text">مقیاس: <?php echo esc_html( $display_unit ); ?></span>
                        </div>
                        <?php if ( $has_values ) { ?>
                        <div class="kph-chart-legend">
                            <span><i aria-hidden="true"></i>بازهٔ انتخابی</span>
                            <label><input type="checkbox" class="kph-compare-toggle" checked aria-label="<?php echo esc_attr( 'نمایش بازهٔ قبلی در ' . $section['title'] ); ?>"><i class="previous" aria-hidden="true"></i>بازهٔ قبلی</label>
                        </div>
                        <?php } ?>
                    </div>
                    <?php if ( ! $has_values ) { ?>
                        <p class="alert alert-light mb-0">مقدار این شاخص در هر دو بازه صفر است.</p>
                    <?php } else { ?>
                            <div class="atlas-chart atlas_chart kph-chart-frame"
                                 data-sales-report="1"
                                 data-display-divisor="<?php echo esc_attr( $display_divisor ); ?>"
                                 data-display-unit="<?php echo esc_attr( $display_unit ); ?>"
                                 data-period-labels='<?php echo esc_attr( wp_json_encode( $comparison_labels ) ); ?>'
                                 role="img" aria-label="<?php echo esc_attr( $section['title'] . '؛ مقادیر دقیق در جدول مقایسهٔ دوره‌ها در ادامهٔ صفحه در دسترس است.' ); ?>"
                                 data-chart-type="<?php echo esc_attr( $section['type'] ); ?>"
                                 data-chart-height="300"
                                 data-color='["#6d4aff","#c47f27"]'
                                 data-tension="0"
                                 data-fill="false"
                                 data-point-radius="3"
                                 data-tooltip-mode="index"
                                 data-tooltip-intersect="0"
                                 data-label='<?php echo esc_attr( wp_json_encode( $dataset_labels ) ); ?>'
                                 data-unit="<?php echo esc_attr( $section['unit'] ); ?>"
                                 data-labels='<?php echo esc_attr( wp_json_encode( $axis_labels ) ); ?>'
                                 data-data='<?php echo esc_attr( wp_json_encode( $section['chart']['data'] ) ); ?>'></div>
                        <div class="kph-chart-foot">تاریخ‌های محور مربوط به بازهٔ انتخابی است؛ لمس نمودار، تاریخ و مقدار دقیق هر دو بازه را نشان می‌دهد.</div>
                    <?php } ?>
                    <details class="kph-method"><summary>راهنمای این نمودار</summary><?php echo esc_html( $section['help'] ); ?></details>
                </div>
            </div>
        </div>
    <?php } ?>
<?php } ?>

<div class="nk-block">
    <div class="card">
        <div class="card-inner">
            <div class="kph-chart-head"><h6 class="title">جدول اعداد دقیق و مقایسهٔ دوره‌ها (ریال)</h6><?php echo $sales_print_button( 'comparison', 'پرینت جدول مقایسهٔ دوره‌ها' ); ?></div>
            <details>
                <summary>مشاهدهٔ جدول مقایسهٔ دوره‌ها</summary>
                <p class="sub-text">هر ردیف، دو دورهٔ هم‌موقعیت در بازهٔ انتخابی و قبلی را مقایسه می‌کند. صفر یعنی مقدار ثبت‌شده برای آن شاخص صفر است. درصد تغییر = اختلاف دو مقدار ÷ قدرمطلق مقدار قبلی × ۱۰۰.</p>
                <div class="table-responsive" tabindex="0" role="region" aria-label="جدول مقایسهٔ دوره‌ها">
                    <table class="kph-report-table">
                        <caption>جزئیات نمودارها؛ مبالغ به ریال و تعدادها به سفارش</caption>
                        <thead><tr>
                            <th scope="col">دورهٔ انتخابی</th><th scope="col">دورهٔ قبلی</th>
                            <th scope="col">فروش انتخابی</th><th scope="col">فروش قبلی</th><th scope="col">تغییر فروش</th>
                            <th scope="col">برکت انتخابی</th><th scope="col">برکت قبلی</th><th scope="col">تغییر برکت</th>
                            <th scope="col">سفارش انتخابی</th><th scope="col">سفارش قبلی</th>
                        </tr></thead>
                        <tbody>
                            <?php foreach ( $chart_report['ranges']['buckets'] as $index => $bucket ) { ?>
                                <tr>
                                    <th scope="row"><?php echo esc_html( $bucket_label( $bucket['current_key'] ) ); ?></th>
                                    <td><?php echo esc_html( $bucket_label( $bucket['previous_key'] ) ); ?></td>
                                    <?php foreach ( [ $sales_chart, $profit_chart ] as $chart ) { ?>
                                        <td><bdi><?php echo esc_html( number_format_i18n( $chart['data'][0][$index] ) ); ?></bdi></td>
                                        <td><bdi><?php echo esc_html( number_format_i18n( $chart['data'][1][$index] ) ); ?></bdi></td>
                                        <td><?php echo $change_badge( $chart['data'][0][$index], $chart['data'][1][$index] ); ?></td>
                                    <?php } ?>
                                    <td><?php echo esc_html( number_format_i18n( $orders_chart['data'][0][$index] ) ); ?></td>
                                    <td><?php echo esc_html( number_format_i18n( $orders_chart['data'][1][$index] ) ); ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                        <tfoot><tr>
                            <th scope="row" colspan="2">جمع کل بازه</th>
                            <?php foreach ( [ 'sales', 'profit' ] as $metric ) { ?>
                                <td><bdi><?php echo esc_html( number_format_i18n( $current_summary[$metric] ) ); ?></bdi></td>
                                <td><bdi><?php echo esc_html( number_format_i18n( $previous_summary[$metric] ) ); ?></bdi></td>
                                <td><?php echo $change_badge( $current_summary[$metric], $previous_summary[$metric] ); ?></td>
                            <?php } ?>
                            <td><?php echo esc_html( number_format_i18n( $current_summary['order_count'] ) ); ?></td>
                            <td><?php echo esc_html( number_format_i18n( $previous_summary['order_count'] ) ); ?></td>
                        </tr></tfoot>
                    </table>
                </div>
            </details>
        </div>
    </div>
</div>

<div class="nk-block-head nk-block-head-sm">
    <h3 class="nk-block-title">وضعیت سفارش‌ها در بازهٔ انتخابی <?php echo $sales_print_button( 'status', 'پرینت وضعیت سفارش‌ها' ); ?></h3>
    <p class="sub-text mb-0">تعداد کل و کسری شامل همهٔ وضعیت‌هاست؛ مبلغ پیش‌فاکتور جدا از فروش واقعی گزارش می‌شود.</p>
</div>

<div class="nk-block">
    <div class="row g-gs">
        <div class="col-md-3">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-0">
                        <div class="card-title">
                            <h6 class="title">تعداد کل سفارشات</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summary['total_invoices'] ); ?>
                                <small class="currency currency-usd fs-12px">سفارش</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-0">
                        <div class="card-title">
                            <h6 class="title">سفارشات تایید شده</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summary['total_registered'] ); ?>
                                <small class="currency currency-usd fs-12px">سفارش</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-0">
                        <div class="card-title">
                            <h6 class="title">تعداد اقلام ارسال‌نشده</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summary['total_shortage_qty'] ); ?>
                                <small class="currency currency-usd fs-12px">کالا</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-0">
                        <div class="card-title">
                            <h6 class="title">مبلغ پیش‌فاکتورها</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summary['total_proforma_amount'] ); ?>
                                <small class="currency currency-usd fs-12px">ریال</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">جزئیات فروش و برکت محصولات <?php echo $sales_print_button( 'products', 'پرینت جزئیات فروش محصولات' ); ?></h3>
            <p class="sub-text mb-0">بهای تمام‌شده شامل ارسال‌های پولی و هدیه است. حاشیهٔ برکت = برکت ناخالص ÷ فروش × ۱۰۰؛ در نبود فروش مثبت، «—» نمایش داده می‌شود. تعداد سفارش هر محصول مستقل است و جمع این ستون تعداد سفارش‌های یکتا نیست.</p>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد سفارشات</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد ارسال شده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">فروش ارسال‌شده (ریال)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">بهای تمام‌شده (ریال)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برکت ناخالص (ریال)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">حاشیهٔ برکت (٪)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد ارسال‌نشده (با هدایا)</span></div>
                    </div>
					
					<?php
					if ( empty( $items ) ) {
						echo '<div class="no-item-found">آیتمی یافت نشد</div>';
					} else {
						foreach ( $items as $entry ) {
							$gross_profit = (float) $entry['total_sales_amount'] - (float) $entry['total_cogs'];
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col text-dark">
                                    <div class="user-card">
                                        <div class="user-info">
                                            <span
                                                class="tb-lead"><?php echo esc_html( get_the_title( $entry['wc_product_id'] ) ); ?></span>
                                            <span
                                                class="sub-text"><?php echo esc_html( $entry['unique_product_code'] ); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="nk-tb-col"><?php echo number_format( $entry['order_count'] ); ?></div>

                                <div class="nk-tb-col">
                                    <strong class="fs-14px"><?php echo number_format( $entry['shipped_paid_qty'] ); ?>
                                        عدد کالا</strong>
									<?php if ( $entry['shipped_free_qty'] ) { ?>
                                        <span
                                            class="sub-text">+<?php echo number_format( $entry['shipped_free_qty'] ); ?> هدیه</span>
									<?php } ?>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['total_sales_amount'] ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['total_cogs'] ); ?></span>
                                </div>

                                <div class="nk-tb-col">
									<span class="<?php echo $gross_profit >= 0 ? 'text-success' : 'text-danger'; ?>">
										<?php echo number_format( $gross_profit ); ?>
									</span>
                                </div>

                                <div class="nk-tb-col">
                                    <bdi><?php echo $entry['total_sales_amount'] > 0 ? esc_html( number_format_i18n( $gross_profit / $entry['total_sales_amount'] * 100, 2 ) ) . '٪' : '—'; ?></bdi>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['total_shortage_qty'] ); ?></span>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
