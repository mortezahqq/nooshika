<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$DB     = new kph_db();
echo kph_get_template( 'partials/visitor-monthly-sales.php' );
$intros = $DB->get_introduce_methods();
$colors = [
	'success',
	'warning',
	'info',
	'pink',
	'teal',
	'purple',
	'orange',
	'azure',
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">مدیریت تولید</h3>
            <div class="nk-block-des text-soft">
                <p>به داشبورد مدیریت تولید خوش آمدید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-xxl-8 col-lg-7">
        </div>
    </div>
</div>
