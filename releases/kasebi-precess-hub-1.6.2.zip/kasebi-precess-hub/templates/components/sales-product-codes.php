<?php
if (!defined('ABSPATH')) { exit; }
$sales_products = $DB->sales_product_code_catalog();
?>
<p class="text-soft">کد را به محصول فروشگاهی وصل کنید. کدهای تولید و موجودی انبار تغییر نمی‌کنند.</p>
<div class="form-group">
    <div class="form-control-wrap"><input type="search" class="form-control kph-product-code-filter" placeholder="جستجوی نام یا کد محصول" aria-label="جستجوی نام یا کد محصول"></div>
</div>
<div class="card card-bordered mt-2">
    <div class="card-inner p-0">
        <div class="nk-tb-list nk-tb-ulist is-compact">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col"><span class="sub-text">نام محصول</span></div>
                <div class="nk-tb-col"><span class="sub-text">کد محصول</span></div>
                <div class="nk-tb-col nk-tb-col-tools text-end">
                    <button type="button" class="btn btn-sm btn-icon kph-new-sales-product" data-bs-toggle="modal" data-bs-target="#kphSalesProductCode" aria-label="افزودن محصول با کد"><em class="icon ni ni-plus"></em></button>
                </div>
            </div>
            <?php foreach ($sales_products as $product): ?>
            <div class="nk-tb-item kph-product-code-row" data-product-id="<?php echo esc_attr($product['id']); ?>">
                <div class="nk-tb-col"><span class="lead-text kph-product-title"><?php echo esc_html($product['post_title']); ?></span></div>
                <div class="nk-tb-col"><span class="kph-saved-product-code" dir="ltr"><?php echo esc_html($product['code'] !== '' ? $product['code'] : '—'); ?></span></div>
                <div class="nk-tb-col nk-tb-col-tools">
                    <button type="button" class="btn btn-sm btn-icon kph-edit-sales-code" data-product-id="<?php echo esc_attr($product['id']); ?>" data-code="<?php echo esc_attr($product['code']); ?>" data-bs-toggle="modal" data-bs-target="#kphSalesProductCode" aria-label="ویرایش کد محصول"><em class="icon ni ni-edit"></em></button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <p class="p-3 text-soft kph-product-code-empty <?php echo $sales_products ? 'd-none' : ''; ?>">محصولی برای نمایش وجود ندارد.</p>
    </div>
</div>
<div class="modal fade zoom" id="kphSalesProductCode">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body">
                <h5 class="modal-title">کد محصول فروشگاهی</h5>
                <form class="mt-4 kph-product-code-form">
                    <div class="row g-gs">
                        <div class="col-md-6"><div class="form-group">
                            <label class="form-label" for="kphCodeProduct">محصول موجود</label>
                            <div class="form-control-wrap"><select id="kphCodeProduct" class="form-select" name="product_id">
                                <option value="0">ساخت محصول جدید</option>
                                <?php foreach ($sales_products as $product): ?><option value="<?php echo esc_attr($product['id']); ?>"><?php echo esc_html($product['post_title']); ?></option><?php endforeach; ?>
                            </select></div>
                        </div></div>
                        <div class="col-md-6"><div class="form-group">
                            <label class="form-label" for="kphSettingsProductCode">کد محصول</label>
                            <div class="form-control-wrap"><input type="text" id="kphSettingsProductCode" class="form-control" name="product_code" maxlength="64" dir="ltr" autocomplete="off" required></div>
                        </div></div>
                        <div class="col-12 kph-new-product-name"><div class="form-group">
                            <label class="form-label" for="kphSettingsProductName">نام محصول جدید</label>
                            <div class="form-control-wrap"><input type="text" id="kphSettingsProductName" class="form-control" name="title" maxlength="190"></div>
                        </div></div>
                        <div class="col-12"><p class="kph-settings-code-message text-soft" role="status" aria-live="polite"></p></div>
                        <div class="col-12"><ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                            <li><button type="submit" class="btn btn-primary">ذخیره</button></li>
                            <li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li>
                        </ul></div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
