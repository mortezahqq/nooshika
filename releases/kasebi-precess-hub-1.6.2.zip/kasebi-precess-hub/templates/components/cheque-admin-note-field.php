<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
?>
<div class="col-12">
    <div class="form-group">
        <label class="form-label" for="new_cheque_admin_note">یادداشت داخلی <span class="text-soft">(فقط ادمین)</span></label>
        <div class="form-control-wrap">
            <textarea class="form-control" id="new_cheque_admin_note" data-for="admin_note" rows="3"
                      maxlength="5000" placeholder="یادداشت مربوط به این چک…"
                      aria-describedby="new_cheque_admin_note_help"></textarea>
        </div>
        <small class="form-text text-soft" id="new_cheque_admin_note_help">اختیاری؛ فقط برای ادمین قابل مشاهده است. چاپ آن با گزینه زیر انتخاب می‌شود.</small>
        <label class="d-block mt-2"><input type="checkbox" data-for="admin_note_print" value="1"> نمایش یادداشت داخلی در چاپ این چک</label>
        <input type="hidden" data-for="admin_note_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kph_cheque_admin_note' ) ); ?>">
    </div>
</div>
