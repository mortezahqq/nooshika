<?php
if(!defined('ABSPATH')||!kph_preparation_print_allowed()||empty($order_id)){return;}
static $selection_number=0;$selection_id='kph-preparation-select-'.absint($order_id).'-'.(++$selection_number);
?>
<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input kph-preparation-select" id="<?php echo esc_attr($selection_id);?>" value="<?php echo esc_attr(absint($order_id));?>" data-viewer="<?php echo esc_attr(get_current_user_id());?>" aria-label="<?php echo esc_attr('انتخاب پیش‌فاکتور شماره '.absint($order_id).' برای آماده‌سازی');?>"><label class="custom-control-label" for="<?php echo esc_attr($selection_id);?>"></label></div>
