<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$cheque_admin_note = $DB->get_cheque_meta( (int) $cheque_id, 'admin_note' );
if ( ! is_string( $cheque_admin_note ) || $cheque_admin_note === '' ) { return; }
?>
<details class="mt-2" style="max-width: 280px; white-space: normal;">
    <summary class="text-primary" style="cursor: pointer;">یادداشت داخلی <small>(فقط ادمین)</small></summary>
    <div class="mt-2 text-break" style="white-space: pre-wrap;"><?php echo esc_html( $cheque_admin_note ); ?></div>
    <label class="d-block mt-2"><input type="checkbox" class="cheque-note-print-toggle" data-cheque-id="<?php echo esc_attr( $cheque_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_cheque_admin_note' ) ); ?>" <?php checked( (string) $DB->get_cheque_meta( (int) $cheque_id, 'admin_note_print' ), '1' ); ?>> نمایش یادداشت داخلی در چاپ این چک</label>
</details>
