<?php
if(!defined('ABSPATH')||!current_user_can('manage_options')){return;}
$DB=isset($DB)?$DB:new kph_db();$ready=$DB->workflow_storage_ready();
$cardamom=$DB->preview_cardamom_code_repair();
?>
<div class="card">
    <h2>اصلاح کد هل ممتاز</h2>
    <?php if ($cardamom['status'] === 'success' && $cardamom['data']['state'] === 'done'): ?>
        <div class="notice notice-success inline"><p>اصلاح کد هل ممتاز انجام شده است. موجودی دوباره اضافه نمی‌شود. اکنون فرم سالن تولید را تازه کنید.</p></div>
    <?php elseif ($cardamom['status'] === 'success'): $preview=$cardamom['data']; ?>
        <p>در یک تولید قدیمی، «هل ممتاز هشت‌گرمی» با کد پنج‌گرمی ثبت شده است. این ابزار، کد را بر اساس نام محصول اصلاح می‌کند.</p>
        <table class="widefat striped"><tbody>
            <tr><th>محصول</th><td><?php echo esc_html($preview['title']); ?></td></tr>
            <tr><th>کد فعلی ← کد صحیح</th><td><span dir="ltr">0505330 → 0808330</span></td></tr>
            <tr><th>تعداد جابه‌جا‌شونده</th><td>۴۴ بسته از همان موجودی قبلی</td></tr>
            <tr><th>موجودی هل هشت‌گرمی پس از اصلاح</th><td><?php echo esc_html((int)$preview['target']['qty_available'] + 44); ?> بسته</td></tr>
        </tbody></table>
        <p>وزن هر بسته در این سابقه ۵ گرم ذخیره شده است. این اصلاح فقط کد را با نام محصول هماهنگ می‌کند؛ تعداد کل، وزن و هزینهٔ ثبت‌شدهٔ تولید حفظ می‌شود و سند مالی تازه‌ای برای مشتری ثبت نمی‌شود.</p>
        <p>ابتدا از دیتابیس بکاپ بگیرید و اصلاح را در زمان توقف ثبت تولید و سفارش انجام دهید.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="kph_cardamom_code_repair">
            <input type="hidden" name="preview_token" value="<?php echo esc_attr($preview['token']); ?>">
            <?php wp_nonce_field('kph_cardamom_code_repair'); ?>
            <p><button type="submit" class="button button-primary">اصلاح کد هل ممتاز</button></p>
        </form>
    <?php else: ?>
        <p><?php echo esc_html($cardamom['message']); ?></p>
    <?php endif; ?>
</div>
<div class="card"><h2>آماده‌سازی ثبت یکپارچه</h2><p><?php echo $ready?'ثبت یکپارچه آماده است.':'برای ثبت و ویرایش یکپارچه، مدیر باید جدول‌های مرتبط را آماده کند.';?></p><p>قبل از آماده‌سازی از دیتابیس پشتیبان بگیرید. این ابزار ساختار ثبت را آماده می‌کند؛ شناسه‌ها، موجودی و سوابق حفظ می‌شوند.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="kph_workflow_maintenance"><input type="hidden" name="operation" value="prepare"><?php wp_nonce_field('kph_workflow_maintenance');?><button type="submit" class="button button-primary">آماده‌سازی ثبت یکپارچه</button></form></div>
