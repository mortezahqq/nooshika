<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $addresses      array
 * @var $selected       int
 * @var $user_id        int
 */
$states       = WC()->countries->get_states( 'IR' );
$first_name   = get_user_meta( $user_id, 'first_name', TRUE );
$last_name    = get_user_meta( $user_id, 'last_name', TRUE );
$phone_number = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
?>
    <input type="hidden" id="customer_first_name_default" value="<?php echo $first_name; ?>">
    <input type="hidden" id="customer_last_name_default" value="<?php echo $last_name; ?>">
    <input type="hidden" id="customer_phone_num_default" value="<?php echo $phone_number; ?>">
<?php
if ( empty( $addresses ) ) {
	echo '<div class="alert alert-warning">آدرسی ثبت نشده است.</div>';
} else {
	?>
    <ul class="custom-control-group custom-control-vertical w-100">
		<?php
		foreach ( $addresses as $key => $address ) {
			$cities = PWS()::cities( $address['state'] );
			$city   = $cities[ $address['city'] ];
			?>
            <li>
                <div
                    class="custom-control custom-control-sm custom-radio custom-control-pro <?php echo $key ==
					                                                                                   $selected ? 'checked' : ''; ?> select_new_order_address"
                    data-key="<?php echo $key; ?>">
                    <input type="radio" class="custom-control-input" name="order_address_select"
						<?php echo $key == $selected ? 'checked' : ''; ?>
                           id="user_address_<?php echo $key; ?>">
                    <label class="custom-control-label nk-tb-item"
                           for="user_address_<?php echo $key; ?>">
                        <div class="user-info">
                            <span
                                class="lead-text"><?php echo $address['first_name'] . ' ' . $address['last_name'] ?></span>
                            <span class="sub-text"><?php echo $address['phone'] ?></span>
                            <span
                                class="sub-text"><?php echo $states[ $address['state'] ] . '-' . $city; ?></span>
                            <span class="sub-text">آدرس: <?php echo $address['address_1'] ?></span>
                            <span class="sub-text"><?php echo $address['postcode'] ?></span>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools" style="margin-right: auto">
                            <ul class="nk-tb-actions gx-1">
                                <li class="nk-tb-action-hidden">
                                    <div class="btn btn-trigger btn-icon edit_customer_address"
                                         data-bs-toggle="tooltip" data-bs-placement="top"
                                         aria-label="ویرایش آدرس"
                                         data-bs-original-title="ویرایش آدرس"
                                         data-key="<?php echo $key; ?>"
                                         data-first_name="<?php echo $address['first_name']; ?>"
                                         data-last_name="<?php echo $address['last_name']; ?>"
                                         data-phone="<?php echo $address['phone']; ?>"
                                         data-postcode="<?php echo $address['postcode']; ?>"
                                         data-state="<?php echo $address['state']; ?>"
                                         data-city="<?php echo $address['city']; ?>"
                                         data-address_1="<?php echo $address['address_1']; ?>">
                                        <div class="dropdown-toggle" data-bs-toggle="modal"
                                             data-bs-target="#addUserAddress">
                                            <em class="icon ni ni-edit-alt"></em>
                                        </div>
                                    </div>
                                </li>
								<?php
								if ( is_current_user_admin() ) {
									?>
                                    <li class="nk-tb-action-hidden">
                                        <div class="btn btn-trigger btn-icon delete_customer_address"
                                             data-bs-toggle="tooltip" data-bs-placement="top"
                                             aria-label="حذف آدرس" data-key="<?php echo $key; ?>"
                                             data-bs-original-title="حذف آدرس">
                                            <em class="icon ni ni-trash"></em></div>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </label>
                </div>
            </li>
			<?php
		}
		?>
    </ul>
	<?php
}
