<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $items array
 */
?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( empty( $items ) ) {
			echo '<div class="alert alert-warning">محصولی پیدا نشد.</div>';
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
					<?php
					foreach ( $items as $product_data ) {
						extract( $product_data );
						?>
                        <div class="each_customer_product_search_row" data-code="<?php echo $unique_product_code; ?>"
                             data-price="<?php echo $sale_price ?: round( $avg_unit_cost ); ?>"
                             data-id="<?php echo $wc_product_id; ?>"
                             data-title="<?php echo esc_attr($post_title); ?>">
                            <div class="product_title"><?php echo esc_html($post_title); ?><?php if(!empty($customer_code)){ ?><span class="sub-text">کد مشتری: <?php echo esc_html($customer_code); ?></span><?php } ?>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>