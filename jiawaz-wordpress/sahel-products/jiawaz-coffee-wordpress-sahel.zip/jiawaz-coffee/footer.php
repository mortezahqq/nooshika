<?php
defined( 'ABSPATH' ) || exit;
jiawaz_coffee_fragment( 'footer' );
wp_footer();
?>
</body>
</html>
