<?php
defined( 'ABSPATH' ) || exit;
jiawaz_coffee_fragment( 'head' );
wp_head();
?>
</head>
<?php
jiawaz_coffee_fragment( 'body-open' );
wp_body_open();
jiawaz_coffee_fragment( 'header' );
