<?php
/** Theme integration; original presentation is kept in template-parts. */
defined( 'ABSPATH' ) || exit;

function jiawaz_coffee_setup() {
    load_theme_textdomain( 'jiawaz-coffee', get_template_directory() . '/languages' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
}
add_action( 'after_setup_theme', 'jiawaz_coffee_setup' );

/** Output only known, bundled markup, with asset paths adapted to this installation. */
function jiawaz_coffee_fragment( $name ) {
    $allowed = array( 'head', 'body-open', 'header', 'home', 'footer' );
    if ( ! in_array( $name, $allowed, true ) ) {
        return;
    }
    $path = get_template_directory() . '/template-parts/' . $name . '.html';
    if ( ! is_readable( $path ) ) {
        return;
    }
    $markup = file_get_contents( $path );
    if ( false === $markup ) {
        return;
    }
    $base = trailingslashit( get_template_directory_uri() );
    $markup = str_replace( 'assets/', esc_url( $base . 'assets/' ), $markup );
    $markup = str_replace( 'src="design.js"', 'src="' . esc_url( $base . 'design.js' ) . '"', $markup );
    if ( 'home' === $name ) {
        $markup = str_replace( '<!--SAHEL_PRODUCTS_2-->', sahel_product_slides( '2' ), $markup );
        for ( $i = 0; $i < 4; $i++ ) {
            $markup = str_replace( '<!--SAHEL_FEATURED_' . $i . '-->', sahel_product_slides( '3', $i ), $markup );
        }
    }
    // This is trusted, immutable theme markup, not user-provided database content.
    echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

require_once get_template_directory() . '/inc/catalog.php';
require_once get_template_directory() . '/inc/import-products.php';

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'sahel-products', get_template_directory_uri() . '/products.css', array(), '1.1.0' );
    wp_enqueue_script( 'sahel-products', get_template_directory_uri() . '/products.js', array(), '1.1.0', true );
} );
