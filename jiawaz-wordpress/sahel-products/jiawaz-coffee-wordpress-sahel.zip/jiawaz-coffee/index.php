<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main class="custom-container" style="padding-top:40px;padding-bottom:60px;min-height:50vh">
<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h1><?php the_title(); ?></h1>
            <?php the_content(); ?>
            <?php wp_link_pages(); ?>
        </article>
    <?php endwhile; ?>
    <?php the_posts_navigation(); ?>
<?php else : ?>
    <p><?php esc_html_e( 'محتوایی پیدا نشد.', 'jiawaz-coffee' ); ?></p>
<?php endif; ?>
</main>
<?php get_footer(); ?>
