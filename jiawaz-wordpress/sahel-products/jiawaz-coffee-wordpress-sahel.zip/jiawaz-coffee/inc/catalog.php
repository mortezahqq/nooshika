<?php
defined( 'ABSPATH' ) || exit;

function sahel_catalog() {
    static $items = null;
    if ( null === $items ) {
        $raw = file_get_contents( get_template_directory() . '/catalog/products.json' );
        $items = json_decode( $raw, true );
        if ( ! is_array( $items ) ) { $items = array(); }
    }
    return $items;
}

function sahel_product_view( $item ) {
    $base = trailingslashit( get_template_directory_uri() );
    $item['images'] = array_map( function ( $path ) use ( $base ) { return $base . $path; }, $item['gallery'] );
    $item['image_url'] = $base . $item['image'];
    $item['price_html'] = esc_html__( 'استعلام قیمت', 'jiawaz-coffee' );
    $item['url'] = '#sahel-' . $item['slug'];
    if ( function_exists( 'wc_get_product_id_by_sku' ) ) {
        $id = wc_get_product_id_by_sku( $item['sku'] );
        $product = $id ? wc_get_product( $id ) : false;
        if ( get_option( 'sahel_catalog_imported' ) && ( ! $product || 'publish' !== $product->get_status() ) ) { return null; }
        if ( $product && 'publish' === $product->get_status() ) {
            $item['name'] = $product->get_name();
            $item['description'] = wp_strip_all_tags( $product->get_description() );
            $item['url'] = get_permalink( $id );
            if ( '' !== $product->get_price() ) { $item['price_html'] = $product->get_price_html(); }
            $ids = array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
            $urls = array_filter( array_map( function ( $id ) { return wp_get_attachment_image_url( $id, 'full' ); }, $ids ) );
            if ( $urls ) { $item['images'] = array_values( $urls ); $item['image_url'] = $item['images'][0]; }
        }
    }
    return $item;
}

/** Same card classes and arrangement as the original two product sliders. */
function sahel_product_slides( $type, $index = null ) {
    $items = sahel_catalog();
    if ( '3' === $type ) { $items = array_slice( $items, 7, 4 ); }
    if ( null !== $index ) { $items = isset( $items[$index] ) ? array( $items[$index] ) : array(); }
    ob_start();
    foreach ( $items as $item ) {
        $p = sahel_product_view( $item );
        if ( ! $p ) { continue; }
        $payload = array( 'name' => $p['name'], 'description' => $p['description'], 'images' => $p['images'], 'price' => wp_strip_all_tags( $p['price_html'] ), 'url' => $p['url'], 'blend' => $p['blend'] );
        ?>
        <?php if ( null === $index ) : ?><div class="swiper-slide" role="group"><?php endif; ?>
          <div class="product-card product-card-<?php echo esc_attr( $type ); ?>" data-sahel-product="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>">
            <div class="product-card-image">
              <a href="<?php echo esc_url( $p['url'] ); ?>" class="sahel-preview"><img loading="lazy" decoding="async" width="300" height="300" src="<?php echo esc_url( $p['image_url'] ); ?>" alt="<?php echo esc_attr( $p['name'] ); ?>" style="width:100%;aspect-ratio:1;object-fit:contain"></a>
              <div class="product-card-image-overly"><button type="button" class="product-card-overly-btn sahel-preview" aria-label="<?php echo esc_attr( 'مشاهدهٔ ' . $p['name'] ); ?>"><i class="iconly-Show" aria-hidden="true"></i></button></div>
            </div>
            <div class="product-card-content<?php echo '3' === $type ? ' card-content-right' : ''; ?>">
              <a href="<?php echo esc_url( $p['url'] ); ?>" class="sahel-preview"><h3 class="title"><?php echo esc_html( $p['name'] ); ?></h3></a>
              <div class="product-price-container"><div class="product-price"><div class="current-price"><?php echo wp_kses_post( $p['price_html'] ); ?></div></div></div>
              <?php if ( '2' === $type ) : ?><button type="button" class="product-card-2-cart sahel-preview" aria-label="مشاهدهٔ محصول"><i class="icon-plus" aria-hidden="true"></i></button><?php endif; ?>
              <?php if ( '3' === $type ) : ?><div class="product-card-3-buttons"><a href="<?php echo esc_url( $p['url'] ); ?>" class="product-card-3-cart sahel-preview"><span class="product-card-3-cart-icon"><i class="icon-plus" aria-hidden="true"></i></span><span>مشاهدهٔ محصول</span></a></div><?php endif; ?>
            </div>
          </div>
        <?php if ( null === $index ) : ?></div><?php endif; ?>
        <?php
    }
    return ob_get_clean();
}
