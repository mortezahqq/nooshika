<?php
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
    add_theme_page( 'محصولات ساحل', 'محصولات ساحل', 'manage_options', 'sahel-products', 'sahel_import_page' );
} );

function sahel_import_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    $report = get_transient( 'sahel_import_report_' . get_current_user_id() );
    delete_transient( 'sahel_import_report_' . get_current_user_id() );
    ?>
    <div class="wrap" dir="rtl"><h1>محصولات ساحل</h1>
    <p>۱۴ محصول و ۱۵ تصویر همراه قالب هستند و در صفحهٔ نخست نمایش داده می‌شوند. دو تصویر کاپوچینو در گالری همان محصول قرار گرفته‌اند.</p>
    <p>برای ویرایش نام، توضیحات، تصاویر و قیمت از پیشخوان، ووکامرس را فعال و سپس دکمهٔ زیر را انتخاب کنید. محصولات موجود با SKU یکسان بازنویسی نمی‌شوند. قیمت‌ها خالی هستند.</p>
    <?php if ( $report ) : ?><div class="notice notice-info"><p><?php echo esc_html( $report ); ?></p></div><?php endif; ?>
    <?php if ( ! class_exists( 'WC_Product_Simple' ) ) : ?>
      <p>ووکامرس فعال نیست. نمایش محصولات داخل قالب همچنان برقرار است؛ درون‌ریزی به پیشخوان نیاز به ووکامرس دارد.</p>
    <?php else : ?>
      <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
      <input type="hidden" name="action" value="sahel_import_products">
      <?php wp_nonce_field( 'sahel_import_products' ); ?>
      <?php submit_button( 'درون‌ریزی محصولات و تصاویر در ووکامرس' ); ?>
      </form>
    <?php endif; ?></div>
    <?php
}

function sahel_import_image( $relative, $title ) {
    $existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_sahel_bundle_file', 'meta_value' => $relative ) );
    if ( $existing ) { return (int) $existing[0]; }
    // Only paths declared in the bundled catalog reach this function.
    $file = get_template_directory() . '/' . $relative;
    if ( ! is_readable( $file ) ) { return new WP_Error( 'sahel_image', 'فایل تصویر موجود نیست: ' . $relative ); }
    $bytes = file_get_contents( $file );
    if ( false === $bytes ) { return new WP_Error( 'sahel_image', 'خواندن تصویر ممکن نشد.' ); }
    $upload = wp_upload_bits( 'sahel-' . basename( $file ), null, $bytes );
    if ( ! empty( $upload['error'] ) ) { return new WP_Error( 'sahel_upload', $upload['error'] ); }
    $id = wp_insert_attachment( array( 'post_title' => $title, 'post_mime_type' => 'image/webp', 'post_status' => 'inherit' ), $upload['file'], 0, true );
    if ( is_wp_error( $id ) ) { return $id; }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $metadata = wp_generate_attachment_metadata( $id, $upload['file'] );
    if ( is_array( $metadata ) ) { wp_update_attachment_metadata( $id, $metadata ); }
    update_post_meta( $id, '_wp_attachment_image_alt', $title );
    update_post_meta( $id, '_sahel_bundle_file', $relative );
    return $id;
}

add_action( 'admin_post_sahel_import_products', function () {
    if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'دسترسی مجاز نیست.', 'jiawaz-coffee' ) ); }
    check_admin_referer( 'sahel_import_products' );
    if ( ! class_exists( 'WC_Product_Simple' ) ) { wp_die( esc_html__( 'ابتدا ووکامرس را فعال کنید.', 'jiawaz-coffee' ) ); }
    $created = 0; $skipped = 0; $errors = array();
    foreach ( sahel_catalog() as $item ) {
        if ( wc_get_product_id_by_sku( $item['sku'] ) ) { $skipped++; continue; }
        try {
            $image_ids = array();
            foreach ( $item['gallery'] as $file ) {
                $id = sahel_import_image( $file, $item['name'] );
                if ( is_wp_error( $id ) ) { throw new Exception( $id->get_error_message() ); }
                $image_ids[] = $id;
            }
            $product = new WC_Product_Simple();
            $product->set_name( $item['name'] );
            $product->set_slug( 'sahel-' . $item['slug'] );
            $product->set_sku( $item['sku'] );
            $product->set_status( 'publish' );
            $product->set_description( $item['description'] );
            $product->set_short_description( $item['description'] );
            $product->set_regular_price( '' );
            // Stock quantities and availability were not supplied. An unpriced product cannot be purchased.
            $product->set_manage_stock( false );
            $product->set_stock_status( 'outofstock' );
            $product->set_reviews_allowed( false );
            if ( '' !== $item['weight_kg'] ) {
                $unit = get_option( 'woocommerce_weight_unit', 'kg' );
                $product->set_weight( (string) wc_get_weight( (float) $item['weight_kg'], $unit, 'kg' ) );
            }
            if ( $image_ids ) { $product->set_image_id( $image_ids[0] ); $product->set_gallery_image_ids( array_slice( $image_ids, 1 ) ); }
            $term = term_exists( $item['category'], 'product_cat' );
            if ( ! $term ) { $term = wp_insert_term( $item['category'], 'product_cat' ); }
            if ( ! is_wp_error( $term ) ) { $product->set_category_ids( array( (int) ( is_array( $term ) ? $term['term_id'] : $term ) ) ); }
            $product->update_meta_data( '_sahel_catalog_origin', 'Isolate-products.rar' );
            if ( $item['blend'] ) {
                $attr = new WC_Product_Attribute(); $attr->set_name( 'ترکیب قهوه' ); $attr->set_options( array( $item['blend'] ) ); $attr->set_visible( true ); $product->set_attributes( array( $attr ) );
            }
            $product->save(); $created++;
        } catch ( Exception $e ) { $errors[] = $item['name'] . ': ' . $e->getMessage(); }
    }
    if ( ! $errors ) { update_option( 'sahel_catalog_imported', 1, false ); }
    $report = sprintf( 'ایجاد شد: %d؛ از قبل موجود بود: %d.', $created, $skipped );
    if ( $errors ) { $report .= ' خطاها: ' . implode( ' | ', $errors ); }
    set_transient( 'sahel_import_report_' . get_current_user_id(), $report, 300 );
    wp_safe_redirect( admin_url( 'themes.php?page=sahel-products' ) ); exit;
} );
