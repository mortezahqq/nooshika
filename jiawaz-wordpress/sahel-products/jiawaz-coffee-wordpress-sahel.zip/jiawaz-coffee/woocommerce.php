<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main class="custom-container woocommerce" style="padding-top:40px;padding-bottom:60px;min-height:50vh">
<?php if ( function_exists( 'woocommerce_content' ) ) { woocommerce_content(); } ?>
</main>
<?php get_footer(); ?>
