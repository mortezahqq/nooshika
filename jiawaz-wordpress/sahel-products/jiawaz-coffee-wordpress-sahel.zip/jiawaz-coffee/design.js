(() => {
 'use strict';
 const all=(s,r=document)=>[...r.querySelectorAll(s)];
 all('.elementor-swiper').forEach(el=>{
  if(!window.Swiper)return;
  el.classList.remove('swiper-initialized','swiper-horizontal');
  el.querySelector('.swiper-wrapper')?.removeAttribute('style');
  all('.swiper-slide',el).forEach(x=>x.removeAttribute('style'));
  new Swiper(el,{slidesPerView:+el.getAttribute('swiper-items-mobile')||1.2,spaceBetween:20,speed:400,watchOverflow:true,breakpoints:{768:{slidesPerView:+el.getAttribute('swiper-items-tablet')||2.5},1024:{slidesPerView:+el.getAttribute('swiper-items')||4.5}},navigation:{nextEl:el.parentElement.querySelector('.custom-swiper-button-next'),prevEl:el.parentElement.querySelector('.custom-swiper-button-prev')}});
 });
 const dialog=document.createElement('dialog');dialog.className='design-story';dialog.innerHTML='<button aria-label="بستن">×</button><img alt="">';document.body.append(dialog);
 dialog.querySelector('button').onclick=()=>dialog.close();
 dialog.onclick=e=>{if(e.target===dialog)dialog.close()};
 all('.story-item').forEach(a=>a.onclick=e=>{e.preventDefault();const slide=all('#storiesSwiperLg > .swiper-wrapper > .swiper-slide')[+a.dataset.storyIndex];const image=slide?.querySelector('img')||a.querySelector('img');if(image){dialog.querySelector('img').src=image.src;dialog.querySelector('img').alt=a.textContent.trim();dialog.showModal()}});
 // Keep this presentation in the recreated page.
 all('a').forEach(a=>{const href=a.getAttribute('href')||'';if(!href.startsWith('https://jiawaz-coffee.bantaco.ir'))return;a.onclick=e=>{e.preventDefault();const path=new URL(href).pathname;const target=/blog/.test(path)?document.querySelector('.elementor-widget-banta_posts_swiper_2'):/contact/.test(path)?document.querySelector('footer'):/shop|product/.test(path)?document.querySelector('.product-card'):document.querySelector('header');target?.scrollIntoView({behavior:'smooth',block:'start'})}});
 all('form').forEach(f=>f.onsubmit=e=>e.preventDefault());
})();
