<?php
defined( 'ABSPATH' ) || exit;
get_header();
jiawaz_coffee_fragment( 'home' );
get_footer();
