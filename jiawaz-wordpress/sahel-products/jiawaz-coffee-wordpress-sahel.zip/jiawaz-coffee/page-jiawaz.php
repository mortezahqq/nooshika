<?php
/**
 * Template Name: جیاواز — طراحی کامل اصلی
 * Template Post Type: page
 */
defined( 'ABSPATH' ) || exit;
get_header();
jiawaz_coffee_fragment( 'home' );
get_footer();
